import 'package:flutter/material.dart';
import 'package:techstagram/Welcome/components/body.dart';

import 'components/body.dart';

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
